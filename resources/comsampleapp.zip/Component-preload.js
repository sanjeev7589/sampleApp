//@ui5-bundle com/sampleapp/Component-preload.js
sap.ui.require.preload({
	"com/sampleapp/Component.js":function(){
sap.ui.define(["sap/ui/core/UIComponent","sap/ui/Device","com/sampleapp/model/models"],function(e,t,i){"use strict";return e.extend("com.sampleapp.Component",{metadata:{manifest:"json"},init:function(){e.prototype.init.apply(this,arguments);this.getRouter().initialize();this.setModel(i.createDeviceModel(),"device")}})});
},
	"com/sampleapp/controller/App.controller.js":function(){
sap.ui.define(["sap/ui/core/mvc/Controller"],function(e){"use strict";return e.extend("com.sampleapp.controller.App",{onInit(){}})});
},
	"com/sampleapp/controller/View.controller.js":function(){
sap.ui.define(["sap/ui/core/mvc/Controller"],function(e){"use strict";return e.extend("com.sampleapp.controller.View",{onInit:function(){}})});
},
	"com/sampleapp/i18n/i18n.properties":'# This is the resource bundle for com.sampleapp\n\n#Texts for manifest.json\n\n#XTIT: Application name\nappTitle=Sample App\n\n#YDES: Application description\nappDescription=A Fiori application.\n#XTIT: Main view title\ntitle=Sample App',
	"com/sampleapp/manifest.json":'{"_version":"1.58.0","sap.app":{"id":"com.sampleapp","type":"application","i18n":"i18n/i18n.properties","applicationVersion":{"version":"0.0.1"},"title":"{{appTitle}}","description":"{{appDescription}}","resources":"resources.json","sourceTemplate":{"id":"@sap/generator-fiori:basic","version":"1.11.2","toolsId":"01677a69-e692-46b7-8350-f1b368629afd"}},"sap.ui":{"technology":"UI5","icons":{"icon":"","favIcon":"","phone":"","phone@2":"","tablet":"","tablet@2":""},"deviceTypes":{"desktop":true,"tablet":true,"phone":true}},"sap.ui5":{"flexEnabled":true,"dependencies":{"minUI5Version":"1.119.0","libs":{"sap.m":{},"sap.ui.core":{},"sap.f":{},"sap.suite.ui.generic.template":{},"sap.ui.comp":{},"sap.ui.generic.app":{},"sap.ui.table":{},"sap.ushell":{}}},"contentDensities":{"compact":true,"cozy":true},"models":{"i18n":{"type":"sap.ui.model.resource.ResourceModel","settings":{"bundleName":"com.sampleapp.i18n.i18n"}}},"resources":{"css":[{"uri":"css/style.css"}]},"routing":{"config":{"routerClass":"sap.m.routing.Router","viewType":"XML","async":true,"viewPath":"com.sampleapp.view","controlAggregation":"pages","controlId":"app","clearControlAggregation":false},"routes":[{"name":"RouteView","pattern":":?query:","target":["TargetView"]}],"targets":{"TargetView":{"viewType":"XML","transition":"slide","clearControlAggregation":false,"viewId":"View","viewName":"View"}}},"rootView":{"viewName":"com.sampleapp.view.App","type":"XML","async":true,"id":"App"}}}',
	"com/sampleapp/model/models.js":function(){
sap.ui.define(["sap/ui/model/json/JSONModel","sap/ui/Device"],function(e,n){"use strict";return{createDeviceModel:function(){var i=new e(n);i.setDefaultBindingMode("OneWay");return i}}});
},
	"com/sampleapp/view/App.view.xml":'<mvc:View controllerName="com.sampleapp.controller.App"\n    xmlns:html="http://www.w3.org/1999/xhtml"\n    xmlns:mvc="sap.ui.core.mvc" displayBlock="true"\n    xmlns="sap.m"><App id="app"></App></mvc:View>\n',
	"com/sampleapp/view/View.view.xml":'<mvc:View controllerName="com.sampleapp.controller.View"\n    xmlns:mvc="sap.ui.core.mvc" displayBlock="true"\n    xmlns="sap.m"><Page id="page" title="{i18n>title}"><content /></Page></mvc:View>\n'
});
//# sourceMappingURL=Component-preload.js.map
