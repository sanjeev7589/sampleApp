sap.ui.define(["sap/ui/core/mvc/Controller"],function(e){"use strict";return e.extend("com.sampleapp.controller.App",{onInit(){}})});
//# sourceMappingURL=App.controller.js.map